from setuptools import setup
setup(
    name="packageharry",
    version="0.2",
    description="this is code with harry package",
    long_description="this is a very long description",
    author="harry",
    packages=['packageharry'],
    install_requires=[]
)